import math

print("Name\tAge\tCountry\tCity")      # Using the tab sequence
print("Asabeneh\t250\tFinland\tHelsinki")      # Using the tab sequence